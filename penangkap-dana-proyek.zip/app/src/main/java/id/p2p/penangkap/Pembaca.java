package id.p2p.penangkap;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Membaca teks notifikasi DANA.
 *
 * Yang dianggap UANG MASUK hanya dua pola ini:
 *   1. "Rp150.000 telah diterima dari DIKA PRATAMA"              (transfer, ada nama)
 *   2. "Berhasil top up saldo Rp1.100.000 dari ALTO. Lihat ..."  (dari bank, TANPA nama)
 * Semua yang lain (mis. "Rp5.000.000 telah dikirim ke ...", voucher, promo,
 * info saldo) diabaikan — hasilnya null.
 */
public final class Pembaca {

    public static final class Hasil {
        public final long jumlah;
        public final String nama;     // "" untuk top up (DANA tidak menyebut nama)
        public final String jenis;    // "transfer" | "topup"
        public final String sumber;   // untuk top up: jaringan/bank, mis. "ALTO"
        Hasil(long jumlah, String nama, String jenis, String sumber) {
            this.jumlah = jumlah; this.nama = nama; this.jenis = jenis; this.sumber = sumber;
        }
    }

    // Rp150.000  /  Rp 150.000  /  Rp150.000,00   lalu  "telah diterima dari"  lalu nama
    private static final Pattern POLA = Pattern.compile(
            "^Rp\\s?([0-9]{1,3}(?:\\.[0-9]{3})*|[0-9]+)(?:,[0-9]{1,2})?\\s+telah diterima dari\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);

    // "Berhasil top up saldo Rp1.100.000 dari ALTO. Lihat detailnya di sini!"
    private static final Pattern POLA_TOPUP = Pattern.compile(
            "^Berhasil top up saldo Rp\\s?([0-9]{1,3}(?:\\.[0-9]{3})*|[0-9]+)(?:,[0-9]{1,2})?\\s+dari\\s+(.+?)\\.?(?:\\s+Lihat detail.*)?$",
            Pattern.CASE_INSENSITIVE);

    private Pembaca() {}

    /** Bersihkan emoji & tanda aneh, rapikan spasi. */
    static String bersihkan(CharSequence cs) {
        if (cs == null) return "";
        String s = cs.toString();
        StringBuilder b = new StringBuilder(s.length());
        int i = 0;
        while (i < s.length()) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isLetterOrDigit(cp) || cp == ' ' || cp == '.' || cp == ',' || cp == '-'
                    || cp == '\'' || cp == '*' || cp == '&' || cp == '/' || cp == '(' || cp == ')') {
                b.appendCodePoint(cp);
            } else {
                b.append(' ');            // emoji, baris baru, dll. jadi spasi
            }
        }
        return b.toString().replaceAll("\\s+", " ").trim();
    }

    private static long angka(String s) {
        try { return Long.parseLong(s.replace(".", "")); } catch (NumberFormatException e) { return -1; }
    }

    public static Hasil baca(CharSequence teksAsli) {
        String teks = bersihkan(teksAsli);
        if (teks.isEmpty()) return null;

        Matcher t = POLA_TOPUP.matcher(teks);
        if (t.matches()) {
            long jumlah = angka(t.group(1));
            String sumber = t.group(2).replaceAll("[\\s.]+$", "").trim();
            if (jumlah <= 0 || sumber.isEmpty() || sumber.length() > 40) return null;
            return new Hasil(jumlah, "", "topup", sumber);
        }

        Matcher m = POLA.matcher(teks);
        if (!m.matches()) return null;
        long jumlah = angka(m.group(1));
        String nama = m.group(2).trim();
        // buang ".." / "…" di ujung (kalau teks sempat terpotong)
        nama = nama.replaceAll("[\\s.]+$", "").trim();
        if (jumlah <= 0 || nama.isEmpty() || nama.length() > 80) return null;
        return new Hasil(jumlah, nama, "transfer", "");
    }
}
