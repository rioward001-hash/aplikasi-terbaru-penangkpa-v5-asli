package id.p2p.penangkap;

import android.app.Notification;
import android.content.ComponentName;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

import java.security.MessageDigest;

/**
 * Membaca notifikasi di HP. Hanya notifikasi dari aplikasi e-wallet ASLI yang
 * diperiksa (dikenali dari identitas paketnya, bukan dari judulnya):
 *   DANA (id.dana), OVO (ovo.id), GoPay (com.gojek.gopay / com.gojek.app).
 * Teksnya diteruskan ke dashboard; dashboard yang membaca mana uang masuk.
 * Notifikasi aplikasi lain (WhatsApp, SMS, Telegram, dll.) langsung diabaikan
 * dan tidak pernah dikirim ke mana pun.
 */
public class DanaListener extends NotificationListenerService {

    static final String PAKET_DANA = "id.dana";

    /** Nama aplikasi e-wallet dari identitas paket, atau null kalau bukan e-wallet. */
    static String aplikasi(String paket) {
        if (paket == null) return null;
        if (paket.equals(PAKET_DANA)) return "DANA";
        if (paket.equals("ovo.id") || paket.startsWith("ovo.id.")) return "OVO";
        if (paket.equals("com.gojek.app") || paket.equals("com.gojek.gopay")) return "GOPAY";
        return null;
    }
    private static final long JEDA_DETAK = 30_000;
    private static final long JEDA_KIRIM = 15_000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean jalan = false;

    private final Runnable putaran = new Runnable() {
        private long detakTerakhir = 0;
        @Override public void run() {
            if (!jalan) return;
            final long kini = System.currentTimeMillis();
            final boolean perluDetak = kini - detakTerakhir >= JEDA_DETAK;
            if (perluDetak) detakTerakhir = kini;
            Jaringan.PEKERJA.execute(() -> {
                Jaringan.kirimAntrian(getApplicationContext());
                if (perluDetak) {
                    Jaringan.detak(getApplicationContext());
                    Jaringan.kirimContoh(getApplicationContext());
                }
            });
            handler.postDelayed(this, JEDA_KIRIM);
        }
    };

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        Penyimpan.catat(this, "Penangkap aktif");
        jalan = true;
        handler.removeCallbacks(putaran);
        handler.post(putaran);
        // Notifikasi DANA yang masih ada di panel (mis. masuk saat aplikasi mati)
        try {
            StatusBarNotification[] ada = getActiveNotifications();
            if (ada != null) for (StatusBarNotification sbn : ada) proses(sbn);
        } catch (Exception ignored) {}
    }

    @Override
    public void onListenerDisconnected() {
        jalan = false;
        handler.removeCallbacks(putaran);
        Penyimpan.catat(this, "Penangkap terputus — menyambung ulang");
        try { requestRebind(new ComponentName(this, DanaListener.class)); } catch (Exception ignored) {}
        super.onListenerDisconnected();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try { proses(sbn); } catch (Exception e) { Penyimpan.catat(this, "error: " + e.getMessage()); }
    }

    private void proses(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (getPackageName().equals(sbn.getPackageName())) {                   // notifikasi aplikasi ini sendiri
            tanganiUji(sbn);
            return;
        }
        String app = aplikasi(sbn.getPackageName());
        if (app == null) return;                                                 // bukan e-wallet asli
        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;          // ringkasan tumpukan
        Bundle ex = n.extras;
        if (ex == null) return;
        CharSequence teks = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (teks == null || teks.length() == 0) teks = ex.getCharSequence(Notification.EXTRA_TEXT);
        if (teks == null) return;
        String bersih = Pembaca.bersihkan(teks);
        if (bersih.isEmpty()) return;

        // Notifikasi yang sama bisa diterima lebih dari sekali (diperbarui / saat
        // penangkap tersambung ulang) → cukup diproses sekali.
        String kunci = sbn.getKey() + "|" + sbn.getPostTime() + "|" + bersih;
        if (Penyimpan.sudahPernah(this, kunci)) return;

        if (!Penyimpan.aktif(this)) {                                            // saklar OFF
            Penyimpan.catat(this, "⏸ dijeda — tidak diteruskan: " + app + " " + potong(bersih));
            return;
        }
        // Teks notifikasi diteruskan APA ADANYA ke dashboard. Dashboard (PC utama)
        // yang memutuskan mana uang masuk & mana yang diabaikan, jadi pola baru
        // cukup ditambahkan di dashboard tanpa memasang ulang aplikasi ini.
        try {
            JSONObject e = new JSONObject();
            e.put("id", sha1(kunci));
            e.put("aplikasi", app);
            e.put("paket", sbn.getPackageName());
            CharSequence judul = ex.getCharSequence(Notification.EXTRA_TITLE);
            e.put("judul", judul == null ? "" : Pembaca.bersihkan(judul));
            e.put("teks", bersih);
            e.put("waktu", sbn.getPostTime());
            Penyimpan.tambahAntrian(this, e);
            Penyimpan.catat(this, "→ " + app + ": " + potong(bersih));
        } catch (Exception ignored) {}
        Jaringan.PEKERJA.execute(() -> Jaringan.kirimAntrian(getApplicationContext()));
    }

    /**
     * Notifikasi uji (v5) tertangkap → laporkan ke dashboard sebagai TES (bukan uang),
     * lalu hapus notifikasinya. Sengaja tetap dilaporkan walau saklar dijeda:
     * HP yang dijeda oleh tes lama perlu bukti ini supaya dashboard menyalakannya lagi.
     */
    private void tanganiUji(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        String kode = n.extras.getString(UjiNotif.KUNCI_EXTRA);
        if (kode == null || kode.isEmpty()) return;                              // notifikasi lain milik aplikasi ini
        if (Penyimpan.sudahPernah(this, "uji|" + kode)) return;
        try {
            JSONObject e = new JSONObject();
            e.put("id", "uji-" + kode);
            e.put("tes", true);
            e.put("uji", kode);
            e.put("waktu", sbn.getPostTime());
            Penyimpan.tambahAntrian(this, e);
            Penyimpan.catat(this, "✓ Notifikasi uji tertangkap (" + kode + ")");
        } catch (Exception ignored) {}
        try { cancelNotification(sbn.getKey()); } catch (Exception ignored) {}
        Jaringan.PEKERJA.execute(() -> Jaringan.kirimAntrian(getApplicationContext()));
    }

    static String rupiah(long x) {
        return String.format(java.util.Locale.US, "%,d", x).replace(',', '.');
    }

    private static String potong(String s) {
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }

    private static String sha1(String s) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
            StringBuilder b = new StringBuilder();
            for (byte x : h) b.append(String.format("%02x", x));
            return b.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }
}
