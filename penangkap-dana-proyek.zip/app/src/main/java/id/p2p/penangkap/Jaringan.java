package id.p2p.penangkap;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Semua komunikasi ke dashboard. Selalu dijalankan di thread terpisah. */
public final class Jaringan {

    public static final ExecutorService PEKERJA = Executors.newSingleThreadExecutor();

    private Jaringan() {}

    public static final class Jawaban {
        public final int kode;
        public final JSONObject isi;
        Jawaban(int kode, JSONObject isi) { this.kode = kode; this.isi = isi; }
        public boolean ok() { return kode == 200 && isi != null && isi.optBoolean("ok"); }
        public String pesan() { return isi == null ? ("HTTP " + kode) : isi.optString("pesan", "HTTP " + kode); }
    }

    public static Jawaban post(String url, String token, JSONObject body) {
        HttpURLConnection k = null;
        try {
            k = (HttpURLConnection) new URL(url).openConnection();
            k.setConnectTimeout(15000);
            k.setReadTimeout(20000);
            k.setRequestMethod("POST");
            k.setDoOutput(true);
            k.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            if (token != null && !token.isEmpty()) k.setRequestProperty("X-HP-Token", token);
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = k.getOutputStream()) { o.write(data); }
            int kode = k.getResponseCode();
            InputStream in = kode >= 400 ? k.getErrorStream() : k.getInputStream();
            String teks = "";
            if (in != null) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                in.close();
                teks = b.toString("UTF-8");
            }
            JSONObject isi = null;
            try { isi = new JSONObject(teks); } catch (Exception ignored) {}
            return new Jawaban(kode, isi);
        } catch (Exception e) {
            JSONObject isi = new JSONObject();
            try { isi.put("ok", false); isi.put("pesan", "tidak tersambung: " + e.getMessage()); } catch (Exception ignored) {}
            return new Jawaban(0, isi);
        } finally {
            if (k != null) k.disconnect();
        }
    }

    public static boolean izinNotifikasi(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        if (s == null) return false;
        String kita = new ComponentName(c, DanaListener.class).flattenToString();
        for (String x : s.split(":")) if (kita.equals(x) || x.startsWith(c.getPackageName() + "/")) return true;
        return false;
    }

    public static boolean bebasBaterai(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    @SuppressWarnings("deprecation")
    public static int versiAplikasi(Context c) {
        try {
            android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? (int) pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) { return 0; }
    }

    /** Kirim semua notifikasi yang masih antri. Aman dipanggil berkali-kali. */
    public static synchronized void kirimAntrian(Context c) {
        String token = Penyimpan.token(c);
        if (token.isEmpty()) return;
        JSONArray a = Penyimpan.antrian(c);
        if (a.length() == 0) return;
        try {
            JSONObject body = new JSONObject();
            body.put("notif", a);
            Jawaban j = post(Penyimpan.server(c) + "/hp/notif", token, body);
            if (j.ok()) {
                Set<String> ids = new HashSet<>();
                JSONArray d = j.isi.optJSONArray("diterima");
                if (d != null) for (int i = 0; i < d.length(); i++) ids.add(d.optString(i));
                Penyimpan.hapusDariAntrian(c, ids);
                JSONObject hasil = j.isi.optJSONObject("hasil");
                if (hasil != null) {
                    java.util.Iterator<String> it = hasil.keys();
                    while (it.hasNext()) {
                        String h = hasil.optString(it.next());
                        Penyimpan.catat(c, "✓ dashboard: " + h);
                        if (h.startsWith("uang masuk")) Penyimpan.simpanTerakhir(c, h.substring(11));
                    }
                }
            } else {
                Penyimpan.simpanPesanServer(c, j.pesan());
                Penyimpan.catat(c, "✗ gagal kirim (akan dicoba lagi): " + j.pesan());
            }
        } catch (Exception e) {
            Penyimpan.catat(c, "✗ gagal kirim: " + e.getMessage());
        }
    }

    /** Kirim contoh teks notifikasi (hanya untuk dipelajari polanya). */
    public static synchronized void kirimContoh(Context c) {
        String token = Penyimpan.token(c);
        if (token.isEmpty()) return;
        JSONArray a = Penyimpan.antrianContoh(c);
        if (a.length() == 0) return;
        try {
            JSONObject body = new JSONObject();
            body.put("contoh", a);
            Jawaban j = post(Penyimpan.server(c) + "/hp/contoh", token, body);
            if (j.ok()) Penyimpan.kosongkanContoh(c, a.length());
        } catch (Exception ignored) {}
    }

    /** Lapor "masih hidup" ke dashboard + ambil nama/nomor & versi terbaru. */
    public static synchronized void detak(Context c) {
        String token = Penyimpan.token(c);
        if (token.isEmpty()) return;
        try {
            JSONObject body = new JSONObject();
            body.put("versi", versiAplikasi(c));
            body.put("izin", izinNotifikasi(c));
            body.put("baterai", bebasBaterai(c));
            body.put("antrian", Penyimpan.jumlahAntrian(c));
            body.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            // Saklar ON/OFF: kalau baru diubah di HP → laporkan; kalau tidak → ikuti dashboard
            boolean lapor = Penyimpan.perluLapor(c);
            boolean aktifSebelum = Penyimpan.aktif(c);
            body.put("aktif", aktifSebelum);
            body.put("ubah_di_hp", lapor);
            Jawaban j = post(Penyimpan.server(c) + "/hp/detak", token, body);
            if (j.ok()) {
                Penyimpan.simpanInfoServer(c, j.isi.optString("nama"), j.isi.optString("nomor"),
                        j.isi.optInt("versi_terbaru", 0));
                Penyimpan.simpanCatatanPembaruan(c, j.isi.optString("catatan_terbaru", ""));
                // v5: perintah notifikasi uji dari dashboard (tes dua arah)
                String uji = j.isi.optString("uji", "");
                if (!uji.isEmpty()) UjiNotif.buat(c, uji);
                if (j.isi.has("aktif")) {
                    boolean aktifServer = j.isi.optBoolean("aktif", true);
                    if (lapor) {
                        Penyimpan.aktifDariServer(c, Penyimpan.aktif(c), true);   // dashboard sudah mencatat
                    } else if (aktifServer != aktifSebelum) {
                        Penyimpan.aktifDariServer(c, aktifServer, false);
                        Penyimpan.catat(c, aktifServer ? "▶ Dinyalakan dari dashboard" : "⏸ Dijeda dari dashboard");
                    }
                }
            } else {
                Penyimpan.simpanPesanServer(c, j.pesan());
            }
        } catch (Exception ignored) {}
    }

    /** Unduh APK terbaru dari dashboard ke cache. Mengembalikan File, atau null kalau gagal. */
    public static File unduhApk(Context c) {
        HttpURLConnection k = null;
        try {
            URL u = new URL(Penyimpan.server(c) + "/hp/apk");
            k = (HttpURLConnection) u.openConnection();
            k.setConnectTimeout(20000);
            k.setReadTimeout(60000);
            k.setInstanceFollowRedirects(true);
            if (k.getResponseCode() != 200) return null;
            File f = new File(c.getExternalCacheDir() != null ? c.getExternalCacheDir() : c.getCacheDir(),
                    "penangkap-update.apk");
            try (InputStream in = k.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return f.length() > 0 ? f : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (k != null) k.disconnect();
        }
    }

    /** Ambil 2 order BUY terakhir + VA dari dashboard. Mengembalikan JSON array (teks) atau null. */
    public static String ambilBuy(Context c) {
        String token = Penyimpan.token(c);
        if (token.isEmpty()) return null;
        try {
            Jawaban j = post(Penyimpan.server(c) + "/hp/buy", token, new JSONObject());
            if (j.ok()) {
                JSONArray a = j.isi.optJSONArray("orders");
                return a == null ? "[]" : a.toString();
            }
        } catch (Exception ignored) {}
        return null;
    }
}
