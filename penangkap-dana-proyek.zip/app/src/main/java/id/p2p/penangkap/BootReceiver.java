package id.p2p.penangkap;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.service.notification.NotificationListenerService;

/** Setelah HP menyala ulang / aplikasi diperbarui: minta penangkap disambungkan lagi. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            NotificationListenerService.requestRebind(new ComponentName(c, DanaListener.class));
        } catch (Exception ignored) {}
        try { OnlineService.perbarui(c); } catch (Exception ignored) {}
        try { BolaService.perbarui(c); } catch (Exception ignored) {}
        Penyimpan.catat(c, "HP menyala / aplikasi diperbarui");
    }
}
