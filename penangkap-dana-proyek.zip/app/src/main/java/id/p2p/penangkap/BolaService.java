package id.p2p.penangkap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Bola melayang yang bisa diketuk. Panelnya berisi:
 *  - password bank: disalin otomatis setiap layar tidak disentuh 2 menit
 *  - 2 order BUY terakhir (dari dashboard) + VA BCA & VA Permata, salin manual.
 * Semua opsional, hanya jalan kalau saklar "Bola pintas" ON di HP ini.
 */
public class BolaService extends Service {

    private static final String CHANNEL = "penangkap_bola";
    private static final int ID_NOTIF = 4202;
    private static final long DIAM_SALIN = 2 * 60_000;     // 2 menit layar tidak disentuh
    private static final long CEK_DIAM = 10_000;           // periksa tiap 10 detik
    private static final long SEGAR_BUY = 15_000;          // ambil order BUY tiap 15 detik

    private static final int HIJAU = Color.rgb(46, 189, 133);
    private static final int ABU = Color.rgb(150, 158, 168);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View bola;
    private View panel;
    private LinearLayout daftarBuy;
    private WindowManager.LayoutParams lpBola;
    private boolean panelTampil = false;

    static BolaService AKTIF;
    private BroadcastReceiver layarRx;
    private volatile long sentuhTerakhir = SystemClock.elapsedRealtime();
    private long salinTerakhir = 0;

    public static void perbarui(Context c) {
        Intent i = new Intent(c, BolaService.class);
        if (Penyimpan.bola(c) && bisaOverlay(c)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i);
            else c.startService(i);
        } else {
            c.stopService(i);
        }
    }

    public static boolean bisaOverlay(Context c) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(c);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        AKTIF = this;
        mulaiForeground();
        daftarReceiverLayar();
        if (bola == null) buatBola();
        handler.removeCallbacks(cekDiam);
        handler.post(cekDiam);
        return START_STICKY;
    }

    private void mulaiForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Bola pintas",
                        NotificationManager.IMPORTANCE_MIN);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setContentTitle("Bola pintas aktif");
        b.setContentText("Ketuk bola untuk password & VA order.");
        b.setSmallIcon(android.R.drawable.ic_dialog_email);
        b.setOngoing(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) b.setPriority(Notification.PRIORITY_MIN);
        startForeground(ID_NOTIF, b.build());
    }

    private int tipeOverlay() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    private void buatBola() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        TextView b = new TextView(this);
        b.setText("Rp");
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(HIJAU);
        int s = dp(52);
        b.setWidth(s); b.setHeight(s);
        bola = b;

        lpBola = new WindowManager.LayoutParams(s, s, tipeOverlay(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lpBola.gravity = Gravity.TOP | Gravity.START;
        lpBola.x = dp(8);
        lpBola.y = dp(180);

        bola.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ax, ay; boolean geser;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ax = lpBola.x; ay = lpBola.y; geser = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - sx), dy = (int) (e.getRawY() - sy);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) geser = true;
                        lpBola.x = ax + dx; lpBola.y = ay + dy;
                        try { wm.updateViewLayout(bola, lpBola); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!geser) toggglePanel();
                        return true;
                }
                return false;
            }
        });
        try { wm.addView(bola, lpBola); } catch (Exception e) {
            Toast.makeText(this, "Bola gagal tampil: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void toggglePanel() {
        if (panelTampil) tutupPanel();
        else bukaPanel();
    }

    private void bukaPanel() {
        tandaiSentuh();
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.rgb(24, 26, 31));
        int p = dp(14);
        box.setPadding(p, p, p, p);
        sv.addView(box);

        judul(box, "Bola pintas");

        // Password
        String pw = Penyimpan.password(this);
        label(box, Penyimpan.autoCopy(this)
                ? "Password bank (otomatis tersalin tiap layar diam 2 menit)"
                : "Password bank");
        Button bPw = tombol(box, pw.isEmpty() ? "Belum diisi — isi lewat aplikasi" : "Salin password");
        bPw.setEnabled(!pw.isEmpty());
        bPw.setOnClickListener(v -> { salin("Password", pw, true); });

        // Order BUY
        label(box, "2 order BUY terakhir");
        daftarBuy = new LinearLayout(this);
        daftarBuy.setOrientation(LinearLayout.VERTICAL);
        box.addView(daftarBuy);
        isiBuy(Penyimpan.buyCache(this));              // tampilkan cache dulu
        ambilBuySekali();                               // lalu segarkan dari dashboard

        Button tutup = tombol(box, "Tutup");
        tutup.setOnClickListener(v -> tutupPanel());

        int lebar = Math.min(getResources().getDisplayMetrics().widthPixels - dp(24), dp(340));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(lebar,
                WindowManager.LayoutParams.WRAP_CONTENT, tipeOverlay(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(12); lp.y = dp(120);
        // setiap sentuhan di panel ikut mereset hitungan diam
        sv.setOnTouchListener((v, e) -> { tandaiSentuh(); return false; });
        panel = sv;
        try { wm.addView(panel, lp); panelTampil = true; } catch (Exception ignored) {}
        handler.removeCallbacks(segarBuy);
        handler.post(segarBuy);
    }

    private void tutupPanel() {
        handler.removeCallbacks(segarBuy);
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; }
        panelTampil = false;
    }

    private void isiBuy(String json) {
        if (daftarBuy == null) return;
        daftarBuy.removeAllViews();
        try {
            JSONArray a = new JSONArray(json);
            if (a.length() == 0) { label(daftarBuy, "Belum ada order BUY berjalan."); return; }
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                LinearLayout kartu = new LinearLayout(this);
                kartu.setOrientation(LinearLayout.VERTICAL);
                kartu.setBackgroundColor(Color.rgb(32, 35, 41));
                int p = dp(10);
                kartu.setPadding(p, p, p, p);
                LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                klp.bottomMargin = dp(8);
                kartu.setLayoutParams(klp);

                TextView t = new TextView(this);
                long idr = (long) o.optDouble("idr", 0);
                t.setText(o.optString("akun") + " · Rp" + String.format(java.util.Locale.US, "%,d", idr).replace(',', '.'));
                t.setTextColor(Color.WHITE); t.setTextSize(14); t.setTypeface(Typeface.DEFAULT_BOLD);
                kartu.addView(t);

                TextView t2 = new TextView(this);
                t2.setText(o.optString("nama") + " · " + o.optString("metode"));
                t2.setTextColor(ABU); t2.setTextSize(12);
                kartu.addView(t2);

                String bca = o.optString("va_bca", ""), permata = o.optString("va_permata", "");
                if (!bca.isEmpty()) tombolVa(kartu, "Salin VA BCA", bca);
                if (!permata.isEmpty()) tombolVa(kartu, "Salin VA Permata", permata);
                if (bca.isEmpty() && permata.isEmpty()) {
                    String rek = o.optString("rekening", "");
                    if (!rek.isEmpty()) tombolVa(kartu, "Salin rekening", rek);
                }
                daftarBuy.addView(kartu);
            }
        } catch (Exception e) {
            label(daftarBuy, "Gagal memuat order.");
        }
    }

    private void tombolVa(LinearLayout tujuan, String teks, final String nilai) {
        Button b = tombol(tujuan, teks + ": " + nilai);
        b.setOnClickListener(v -> salin(teks, nilai, false));
    }

    private void ambilBuySekali() {
        Jaringan.PEKERJA.execute(() -> {
            String json = Jaringan.ambilBuy(getApplicationContext());
            if (json != null) {
                Penyimpan.simpanBuy(getApplicationContext(), json);
                handler.post(() -> { if (panelTampil) isiBuy(json); });
            }
        });
    }

    private final Runnable segarBuy = new Runnable() {
        @Override public void run() {
            if (!panelTampil) return;
            ambilBuySekali();
            handler.postDelayed(this, SEGAR_BUY);
        }
    };

    /** Layar NYALA dianggap "sedang dipakai" (hitungan diam diulang). Saat layar
        MATI, hitungan diam berjalan; jadi auto-copy terjadi setelah layar mati /
        HP didiamkan selama 2 menit — pas untuk disalin sebelum buka aplikasi bank. */
    private void daftarReceiverLayar() {
        if (layarRx != null) return;
        layarRx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                if (Intent.ACTION_SCREEN_ON.equals(a) || Intent.ACTION_USER_PRESENT.equals(a)) tandaiSentuh();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_USER_PRESENT);
        try { registerReceiver(layarRx, f); } catch (Exception ignored) {}
    }

    // ── auto-copy password tiap layar diam 2 menit ──
    public void tandaiSentuh() { sentuhTerakhir = SystemClock.elapsedRealtime(); }

    private final Runnable cekDiam = new Runnable() {
        @Override public void run() {
            try {
                if (Penyimpan.bola(getApplicationContext()) && Penyimpan.autoCopy(getApplicationContext())) {
                    String pw = Penyimpan.password(getApplicationContext());
                    long kini = SystemClock.elapsedRealtime();
                    if (!pw.isEmpty() && kini - sentuhTerakhir >= DIAM_SALIN
                            && kini - salinTerakhir >= DIAM_SALIN) {
                        salin("Password", pw, false);
                        salinTerakhir = kini;
                    }
                }
            } catch (Exception ignored) {}
            handler.postDelayed(this, CEK_DIAM);
        }
    };

    private void salin(String labelClip, String isi, boolean beriTahu) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(labelClip, isi));
            if (beriTahu) Toast.makeText(this, labelClip + " disalin", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    // ── pembuat tampilan ──
    private void judul(LinearLayout box, String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(6));
        box.addView(t);
    }
    private void label(LinearLayout box, String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(ABU); t.setTextSize(12);
        t.setPadding(0, dp(8), 0, dp(4));
        box.addView(t);
    }
    private Button tombol(LinearLayout box, String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        box.addView(b);
        return b;
    }

    @Override public void onDestroy() {
        if (AKTIF == this) AKTIF = null;
        if (layarRx != null) { try { unregisterReceiver(layarRx); } catch (Exception ignored) {} layarRx = null; }
        handler.removeCallbacks(cekDiam);
        handler.removeCallbacks(segarBuy);
        tutupPanel();
        if (bola != null) { try { wm.removeView(bola); } catch (Exception ignored) {} bola = null; }
        super.onDestroy();
    }
}
