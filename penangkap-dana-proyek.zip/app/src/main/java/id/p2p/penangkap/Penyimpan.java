package id.p2p.penangkap;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Pengaturan, antrian kiriman, dan catatan kecil — semuanya di SharedPreferences. */
public final class Penyimpan {

    public static final String SERVER_BAWAAN = "https://app.jembarsot.my.id";
    private static final String NAMA = "penangkap";
    private static final int MAKS_ANTRIAN = 500;
    private static final int MAKS_CATATAN = 40;
    private static final int MAKS_SUDAH = 400;
    private static final Object KUNCI = new Object();

    private Penyimpan() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAMA, Context.MODE_PRIVATE);
    }

    // ── pengaturan ──
    public static String server(Context c) {
        String s = sp(c).getString("server", SERVER_BAWAAN);
        return s == null || s.trim().isEmpty() ? SERVER_BAWAAN : s.trim().replaceAll("/+$", "");
    }
    public static String token(Context c) { return sp(c).getString("token", ""); }
    public static String namaHp(Context c) { return sp(c).getString("nama", ""); }
    public static String nomor(Context c) { return sp(c).getString("nomor", ""); }
    public static int versiTerbaru(Context c) { return sp(c).getInt("versi_terbaru", 0); }
    public static long terakhirDetak(Context c) { return sp(c).getLong("detak_ok", 0); }
    public static String pesanServer(Context c) { return sp(c).getString("pesan_server", ""); }
    public static String catatanPembaruan(Context c) { return sp(c).getString("catatan_terbaru", ""); }
    // Kode notifikasi uji terakhir yang sudah dibuat (supaya satu kode = satu notifikasi)
    public static String ujiTerakhir(Context c) { return sp(c).getString("uji_terakhir", ""); }
    public static void simpanUjiTerakhir(Context c, String kode) { sp(c).edit().putString("uji_terakhir", kode).apply(); }

    public static void simpanPendaftaran(Context c, String server, String token, String nama, String nomor) {
        sp(c).edit().putString("server", server).putString("token", token)
                .putString("nama", nama).putString("nomor", nomor).apply();
    }
    public static void simpanInfoServer(Context c, String nama, String nomor, int versiTerbaru) {
        sp(c).edit().putString("nama", nama).putString("nomor", nomor)
                .putInt("versi_terbaru", versiTerbaru).putLong("detak_ok", System.currentTimeMillis())
                .putString("pesan_server", "").apply();
    }
    public static void simpanCatatanPembaruan(Context c, String catatan) {
        sp(c).edit().putString("catatan_terbaru", catatan == null ? "" : catatan).apply();
    }
    // ── saklar penangkap (ON/OFF) — bisa diubah dari aplikasi maupun dashboard ──
    public static boolean aktif(Context c) { return sp(c).getBoolean("aktif", true); }
    /** true = saklar baru diubah di HP ini dan belum dilaporkan ke dashboard */
    public static boolean perluLapor(Context c) { return sp(c).getBoolean("perlu_lapor", false); }
    public static void ubahAktifDariHp(Context c, boolean aktif) {
        sp(c).edit().putBoolean("aktif", aktif).putBoolean("perlu_lapor", true).apply();
    }
    public static void aktifDariServer(Context c, boolean aktif, boolean sudahDilaporkan) {
        SharedPreferences.Editor e = sp(c).edit().putBoolean("aktif", aktif);
        if (sudahDilaporkan) e.putBoolean("perlu_lapor", false);
        e.apply();
    }

    // ── saklar fitur v4 (per HP, mati secara bawaan kecuali disebut) ──
    public static boolean jagaOnline(Context c) { return sp(c).getBoolean("jaga_online", false); }
    public static void setJagaOnline(Context c, boolean on) { sp(c).edit().putBoolean("jaga_online", on).apply(); }
    public static boolean layarNyala(Context c) { return sp(c).getBoolean("layar_nyala", false); }
    public static void setLayarNyala(Context c, boolean on) { sp(c).edit().putBoolean("layar_nyala", on).apply(); }
    public static boolean bola(Context c) { return sp(c).getBoolean("bola", false); }
    public static void setBola(Context c, boolean on) { sp(c).edit().putBoolean("bola", on).apply(); }

    // ── bola pintas: password & auto-copy ──
    public static String password(Context c) { return sp(c).getString("password", ""); }
    public static void setPassword(Context c, String p) { sp(c).edit().putString("password", p == null ? "" : p).apply(); }
    public static boolean autoCopy(Context c) { return sp(c).getBoolean("auto_copy", false); }
    public static void setAutoCopy(Context c, boolean on) { sp(c).edit().putBoolean("auto_copy", on).apply(); }

    // ── cache 2 order BUY terakhir (dari dashboard) untuk ditampilkan di bola ──
    public static void simpanBuy(Context c, String jsonArray) {
        sp(c).edit().putString("buy_cache", jsonArray == null ? "[]" : jsonArray).apply();
    }
    public static String buyCache(Context c) { return sp(c).getString("buy_cache", "[]"); }

    public static void simpanPesanServer(Context c, String pesan) {
        sp(c).edit().putString("pesan_server", pesan).apply();
    }

    // ── antrian uang masuk yang belum terkirim ──
    public static JSONArray antrian(Context c) {
        synchronized (KUNCI) {
            try { return new JSONArray(sp(c).getString("antrian", "[]")); }
            catch (Exception e) { return new JSONArray(); }
        }
    }
    public static int jumlahAntrian(Context c) { return antrian(c).length(); }

    public static void tambahAntrian(Context c, JSONObject e) {
        synchronized (KUNCI) {
            JSONArray a = antrian(c);
            a.put(e);
            while (a.length() > MAKS_ANTRIAN) a.remove(0);
            sp(c).edit().putString("antrian", a.toString()).apply();
        }
    }

    /** Buang dari antrian semua id yang sudah diterima server. */
    public static void hapusDariAntrian(Context c, java.util.Set<String> ids) {
        synchronized (KUNCI) {
            JSONArray a = antrian(c), sisa = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && !ids.contains(o.optString("id"))) sisa.put(o);
            }
            sp(c).edit().putString("antrian", sisa.toString()).apply();
        }
    }

    // ── antrian contoh notifikasi (OVO/GoPay & DANA yang tidak dikenali) — untuk dipelajari ──
    public static JSONArray antrianContoh(Context c) {
        synchronized (KUNCI) {
            try { return new JSONArray(sp(c).getString("contoh", "[]")); }
            catch (Exception e) { return new JSONArray(); }
        }
    }
    public static void tambahContoh(Context c, JSONObject e) {
        synchronized (KUNCI) {
            JSONArray a = antrianContoh(c);
            a.put(e);
            while (a.length() > 100) a.remove(0);
            sp(c).edit().putString("contoh", a.toString()).apply();
        }
    }
    public static void kosongkanContoh(Context c, int jumlahTerkirim) {
        synchronized (KUNCI) {
            JSONArray a = antrianContoh(c), sisa = new JSONArray();
            for (int i = jumlahTerkirim; i < a.length(); i++) sisa.put(a.opt(i));
            sp(c).edit().putString("contoh", sisa.toString()).apply();
        }
    }

    // ── penjaga dobel: notifikasi yang sama tidak diproses dua kali ──
    public static boolean sudahPernah(Context c, String kunci) {
        synchronized (KUNCI) {
            try {
                JSONArray a = new JSONArray(sp(c).getString("sudah", "[]"));
                for (int i = 0; i < a.length(); i++) if (kunci.equals(a.optString(i))) return true;
                a.put(kunci);
                while (a.length() > MAKS_SUDAH) a.remove(0);
                sp(c).edit().putString("sudah", a.toString()).apply();
            } catch (Exception ignored) {}
            return false;
        }
    }

    // ── catatan singkat yang tampil di layar aplikasi ──
    public static void catat(Context c, String teks) {
        synchronized (KUNCI) {
            JSONArray a;
            try { a = new JSONArray(sp(c).getString("catatan", "[]")); } catch (Exception e) { a = new JSONArray(); }
            String jam = new SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(new Date());
            a.put(jam + "  " + teks);
            while (a.length() > MAKS_CATATAN) a.remove(0);
            sp(c).edit().putString("catatan", a.toString()).apply();
        }
    }
    public static String catatan(Context c) {
        try {
            JSONArray a = new JSONArray(sp(c).getString("catatan", "[]"));
            StringBuilder b = new StringBuilder();
            for (int i = a.length() - 1; i >= 0; i--) b.append(a.optString(i)).append('\n');
            return b.toString();
        } catch (Exception e) { return ""; }
    }
    public static void simpanTerakhir(Context c, String teks) {
        sp(c).edit().putString("terakhir", teks).apply();
    }
    public static String terakhir(Context c) { return sp(c).getString("terakhir", "-"); }
}
