package id.p2p.penangkap;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import java.io.File;

/** Satu layar: status, langkah pemasangan, pendaftaran ke dashboard, catatan. */
public class MainActivity extends Activity {

    private static final int HIJAU = Color.rgb(46, 189, 133);
    private static final int MERAH = Color.rgb(246, 70, 93);
    private static final int ABU = Color.rgb(120, 128, 138);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout isi;
    private TextView tvDaftar, tvIzin, tvBaterai, tvServer, tvTerakhir, tvAntrian, tvCatatan;
    private Button bUpdate;
    private TextView tvPembaruan;
    private Switch swAktif, swOnline, swLayar, swBola, swAutoCopy;
    private boolean isiSaklar = false;
    private EditText inServer, inKode;

    private final Runnable segarkan = new Runnable() {
        @Override public void run() { perbarui(); handler.postDelayed(this, 3000); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        isi = new LinearLayout(this);
        isi.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        isi.setPadding(p, p, p, p);
        sv.addView(isi);
        setContentView(sv);

        judul("Penangkap DANA  v" + Jaringan.versiAplikasi(this), 22);
        teks("Meneruskan notifikasi DANA, OVO, dan GoPay ke dashboard. Dashboard yang menentukan "
                + "mana uang masuk. Notifikasi aplikasi lain tidak pernah dibaca.", 13, ABU);

        // ── Saklar utama ──
        swAktif = new Switch(this);
        swAktif.setText("Penangkap aktif");
        swAktif.setTextSize(18);
        swAktif.setTypeface(Typeface.DEFAULT_BOLD);
        swAktif.setPadding(0, dp(12), 0, dp(4));
        swAktif.setOnCheckedChangeListener((v, nyala) -> {
            if (isiSaklar) return;                        // perubahan dari layar sendiri, bukan tangan
            Penyimpan.ubahAktifDariHp(this, nyala);
            Penyimpan.catat(this, nyala ? "▶ Dinyalakan di HP ini" : "⏸ Dijeda di HP ini");
            toast(nyala ? "Penangkap dinyalakan" : "Penangkap dijeda — uang masuk tidak dikirim");
            Jaringan.PEKERJA.execute(() -> Jaringan.detak(getApplicationContext()));
            perbarui();
        });
        isi.addView(swAktif);
        teks("Saklar ini juga bisa diubah dari dashboard (menu DANA → HP penangkap).", 12, ABU);

        // ── Saklar tambahan (per HP) ──
        swOnline = saklar("Jaga tetap online", "HP tetap terbaca online di dashboard walau layar mati / tidak dicas.",
                Penyimpan.jagaOnline(this), (v, on) -> {
                    Penyimpan.setJagaOnline(this, on);
                    OnlineService.perbarui(this);
                    toast(on ? "HP akan dijaga tetap online" : "Jaga online dimatikan");
                });
        swLayar = saklar("Layar selalu nyala", "Layar tidak mati sendiri sampai saklar ini dimatikan. Sebaiknya HP dicas.",
                Penyimpan.layarNyala(this), (v, on) -> {
                    Penyimpan.setLayarNyala(this, on);
                    OnlineService.perbarui(this);
                    toast(on ? "Layar akan selalu nyala" : "Layar kembali normal");
                });
        swBola = saklar("Bola pintas", "Bola melayang berisi password & VA order BUY. Butuh izin tampil di atas aplikasi lain.",
                Penyimpan.bola(this), (v, on) -> aturBola(on));
        tombol("Isi / ganti password bola", v -> isiPassword());
        swAutoCopy = saklar("Auto-salin password tiap layar diam 2 menit", "Hanya berlaku saat bola pintas menyala.",
                Penyimpan.autoCopy(this), (v, on) -> {
                    Penyimpan.setAutoCopy(this, on);
                    toast(on ? "Password akan otomatis disalin tiap layar diam 2 menit" : "Auto-salin dimatikan");
                });

        // ── Status ──
        subjudul("Status");
        tvDaftar = teks("", 15, Color.BLACK);
        tvIzin = teks("", 15, Color.BLACK);
        tvBaterai = teks("", 15, Color.BLACK);
        tvServer = teks("", 15, Color.BLACK);
        tvTerakhir = teks("", 14, Color.DKGRAY);
        tvAntrian = teks("", 14, Color.DKGRAY);
        bUpdate = tombol("⬇ Update tersedia — unduh & pasang sekarang", v -> jalankanUpdate());
        bUpdate.setVisibility(View.GONE);
        tvPembaruan = teks("", 13, ABU);
        tvPembaruan.setVisibility(View.GONE);

        // ── Langkah pemasangan ──
        subjudul("Langkah pemasangan (sekali per HP)");
        tombol("1. Izinkan akses notifikasi", v -> buka(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        tombol("2. Matikan penghemat baterai untuk aplikasi ini", v -> mintaBebasBaterai());
        tombol("3. Pengaturan aplikasi (izinkan mulai otomatis & aktivitas latar belakang)", v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            buka(i);
        });
        teks("4. Buka daftar aplikasi terbuka, tarik kartu aplikasi ini ke bawah sampai muncul ikon gembok.", 13, ABU);

        // ── Pendaftaran ──
        subjudul("Daftarkan ke dashboard");
        teks("Di dashboard: menu DANA → HP penangkap → + Tambah HP. Ketik kode 6 angka yang muncul.", 13, ABU);
        inServer = isian("Alamat dashboard", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        inServer.setText(Penyimpan.server(this));
        inKode = isian("Kode 6 angka", InputType.TYPE_CLASS_NUMBER);
        tombol("Daftarkan HP ini", v -> daftar());
        tombol("Tes kirim ke dashboard", v -> tesKirim());

        // ── Catatan ──
        subjudul("Catatan terakhir");
        tvCatatan = teks("", 12, Color.DKGRAY);
        tvCatatan.setTypeface(Typeface.MONOSPACE);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        // Sentuhan di layar aplikasi juga dihitung sebagai "layar dipakai"
        if (BolaService.AKTIF != null) BolaService.AKTIF.tandaiSentuh();
        return super.dispatchTouchEvent(ev);
    }

    @Override protected void onResume() {
        super.onResume();
        handler.post(segarkan);
        Jaringan.PEKERJA.execute(() -> {
            Jaringan.detak(getApplicationContext());
            Jaringan.kirimAntrian(getApplicationContext());
        });
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(segarkan);
    }

    private void perbarui() {
        boolean aktif = Penyimpan.aktif(this);
        isiSaklar = true;
        swAktif.setChecked(aktif);
        isiSaklar = false;
        swAktif.setTextColor(aktif ? HIJAU : MERAH);
        swAktif.setText(aktif ? "Penangkap AKTIF" : "Penangkap DIJEDA");
        boolean terdaftar = !Penyimpan.token(this).isEmpty();
        String nomor = Penyimpan.nomor(this);
        status(tvDaftar, terdaftar, terdaftar
                ? "Terdaftar sebagai " + Penyimpan.namaHp(this) + (nomor.isEmpty() ? "" : " · " + nomor)
                : "Belum didaftarkan ke dashboard");
        boolean izin = Jaringan.izinNotifikasi(this);
        status(tvIzin, izin, izin ? "Akses notifikasi: diizinkan" : "Akses notifikasi: BELUM diizinkan (langkah 1)");
        boolean bat = Jaringan.bebasBaterai(this);
        status(tvBaterai, bat, bat ? "Penghemat baterai: dimatikan" : "Penghemat baterai: masih aktif (langkah 2)");

        long detak = Penyimpan.terakhirDetak(this);
        String pesan = Penyimpan.pesanServer(this);
        boolean nyambung = detak > 0 && System.currentTimeMillis() - detak < 3 * 60_000;
        status(tvServer, nyambung, !pesan.isEmpty() ? "Dashboard: " + pesan
                : nyambung ? "Dashboard: tersambung (" + jam(detak) + ")"
                : detak > 0 ? "Dashboard: terakhir tersambung " + jam(detak) : "Dashboard: belum tersambung");
        tvTerakhir.setText("Uang masuk terakhir: " + Penyimpan.terakhir(this));
        int antri = Penyimpan.jumlahAntrian(this);
        tvAntrian.setText("Menunggu dikirim: " + antri + (antri > 0 ? "  (dikirim otomatis saat online)" : ""));
        boolean adaUpdate = Penyimpan.versiTerbaru(this) > Jaringan.versiAplikasi(this);
        bUpdate.setVisibility(adaUpdate ? View.VISIBLE : View.GONE);
        String catatan = Penyimpan.catatanPembaruan(this);
        if (adaUpdate) {
            bUpdate.setText("⬇ Update ke v" + Penyimpan.versiTerbaru(this) + " — unduh & pasang");
            tvPembaruan.setText(catatan.isEmpty() ? "" : "Yang baru:\n" + catatan);
            tvPembaruan.setVisibility(catatan.isEmpty() ? View.GONE : View.VISIBLE);
        } else {
            tvPembaruan.setVisibility(View.GONE);
        }
        tvCatatan.setText(Penyimpan.catatan(this));
        sinkronSaklar();
    }

    private boolean isiSw = false;
    private void sinkronSaklar() {
        isiSw = true;
        if (swOnline != null) swOnline.setChecked(Penyimpan.jagaOnline(this));
        if (swLayar != null) swLayar.setChecked(Penyimpan.layarNyala(this));
        if (swBola != null) swBola.setChecked(Penyimpan.bola(this) && BolaService.bisaOverlay(this));
        if (swAutoCopy != null) swAutoCopy.setChecked(Penyimpan.autoCopy(this));
        isiSw = false;
    }

    private void daftar() {
        final String server = inServer.getText().toString().trim().replaceAll("/+$", "");
        final String kode = inKode.getText().toString().replaceAll("\\D", "");
        if (!server.startsWith("https://")) { toast("Alamat harus diawali https://"); return; }
        if (kode.length() != 6) { toast("Kode harus 6 angka"); return; }
        toast("Mendaftarkan…");
        Jaringan.PEKERJA.execute(() -> {
            JSONObject body = new JSONObject();
            try {
                body.put("kode", kode);
                body.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            } catch (Exception ignored) {}
            Jaringan.Jawaban j = Jaringan.post(server + "/hp/pasang", null, body);
            runOnUiThread(() -> {
                if (j.ok()) {
                    Penyimpan.simpanPendaftaran(this, server, j.isi.optString("token"),
                            j.isi.optString("nama"), j.isi.optString("nomor"));
                    Penyimpan.simpanPesanServer(this, "");
                    Penyimpan.catat(this, "Terdaftar sebagai " + j.isi.optString("nama"));
                    inKode.setText("");
                    toast("✅ Terdaftar sebagai " + j.isi.optString("nama"));
                    Jaringan.PEKERJA.execute(() -> Jaringan.detak(getApplicationContext()));
                } else {
                    toast("Gagal: " + j.pesan());
                }
                perbarui();
            });
        });
    }

    private void tesKirim() {
        if (Penyimpan.token(this).isEmpty()) { toast("Daftarkan HP dulu"); return; }
        try {
            JSONObject e = new JSONObject();
            e.put("id", "tes-" + System.currentTimeMillis());
            e.put("tes", true);
            Penyimpan.tambahAntrian(this, e);
        } catch (Exception ignored) {}
        toast("Mengirim tes…");
        Jaringan.PEKERJA.execute(() -> {
            Jaringan.kirimAntrian(getApplicationContext());
            Jaringan.detak(getApplicationContext());
            runOnUiThread(() -> {
                String pesan = Penyimpan.pesanServer(this);
                toast(pesan.isEmpty() ? "✅ Tes diterima dashboard" : "Gagal: " + pesan);
                perbarui();
            });
        });
    }

    private void mintaBebasBaterai() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            buka(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private boolean sedangUpdate = false;

    private void jalankanUpdate() {
        if (sedangUpdate) return;
        // Android 8+: butuh izin "pasang aplikasi tidak dikenal" untuk aplikasi ini
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !getPackageManager().canRequestPackageInstalls()) {
            toast("Izinkan dulu \"Instal aplikasi tidak dikenal\" untuk aplikasi ini, lalu tekan Update lagi.");
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                buka(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES));
            }
            return;
        }
        sedangUpdate = true;
        bUpdate.setText("Mengunduh update…");
        bUpdate.setEnabled(false);
        toast("Mengunduh update…");
        Jaringan.PEKERJA.execute(() -> {
            File apk = Jaringan.unduhApk(getApplicationContext());
            runOnUiThread(() -> {
                sedangUpdate = false;
                bUpdate.setEnabled(true);
                perbarui();
                if (apk == null) {
                    toast("Gagal mengunduh update. Coba lagi saat sinyal lebih baik.");
                    return;
                }
                pasangApk(apk);
            });
        });
    }

    private void pasangApk(File apk) {
        try {
            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = android.support.v4.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", apk);
            } else {
                uri = Uri.fromFile(apk);
            }
            Intent i = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            i.setData(uri);
            i.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);
            i.putExtra(Intent.EXTRA_RETURN_RESULT, false);
            startActivity(i);
        } catch (Exception e) {
            // Cara cadangan: buka APK lewat VIEW
            try {
                Uri uri = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        ? android.support.v4.content.FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk)
                        : Uri.fromFile(apk);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(uri, "application/vnd.android.package-archive");
                i.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e2) {
                toast("Tidak bisa membuka pemasang: " + e2.getMessage());
            }
        }
    }

    private void buka(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("Tidak bisa membuka pengaturan: " + e.getMessage()); }
    }

    private interface Ubah { void ubah(View v, boolean on); }

    private Switch saklar(String judul, String ket, boolean nilai, Ubah aksi) {
        Switch sw = new Switch(this);
        sw.setText(judul);
        sw.setTextSize(17);
        sw.setTypeface(Typeface.DEFAULT_BOLD);
        sw.setPadding(0, dp(14), 0, dp(2));
        sw.setChecked(nilai);
        sw.setOnCheckedChangeListener((v, on) -> aksi.ubah(v, on));
        isi.addView(sw);
        teks(ket, 12, ABU);
        return sw;
    }

    private void aturBola(boolean on) {
        if (on && !BolaService.bisaOverlay(this)) {
            toast("Izinkan dulu \"Tampil di atas aplikasi lain\" untuk aplikasi ini, lalu nyalakan lagi.");
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                buka(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
            swBola.setChecked(false);
            return;
        }
        Penyimpan.setBola(this, on);
        BolaService.perbarui(this);
        toast(on ? "Bola pintas dinyalakan" : "Bola pintas dimatikan");
    }

    private void isiPassword() {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        in.setText(Penyimpan.password(this));
        in.setHint("Password bank");
        new AlertDialog.Builder(this)
                .setTitle("Password untuk bola pintas")
                .setMessage("Password ini disimpan di HP ini saja dan dipakai untuk disalin dari bola.")
                .setView(in)
                .setPositiveButton("Simpan", (d, w) -> {
                    Penyimpan.setPassword(this, in.getText().toString());
                    toast("Password disimpan");
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // ── pembuat tampilan sederhana ──
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    private TextView teks(String s, int ukuran, int warna) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(ukuran);
        t.setTextColor(warna);
        t.setPadding(0, dp(3), 0, dp(3));
        isi.addView(t);
        return t;
    }
    private void judul(String s, int ukuran) {
        TextView t = teks(s, ukuran, Color.BLACK);
        t.setTypeface(Typeface.DEFAULT_BOLD);
    }
    private void subjudul(String s) {
        TextView t = teks(s, 17, Color.BLACK);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(18), 0, dp(4));
    }
    private Button tombol(String s, View.OnClickListener aksi) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setOnClickListener(aksi);
        isi.addView(b);
        return b;
    }
    private EditText isian(String petunjuk, int jenis) {
        EditText e = new EditText(this);
        e.setHint(petunjuk);
        e.setInputType(jenis);
        e.setSingleLine(true);
        isi.addView(e);
        return e;
    }
    private void status(TextView t, boolean ok, String s) {
        t.setText((ok ? "✅ " : "❌ ") + s);
        t.setTextColor(ok ? HIJAU : MERAH);
    }
    private static String jam(long ms) {
        return new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(ms));
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
