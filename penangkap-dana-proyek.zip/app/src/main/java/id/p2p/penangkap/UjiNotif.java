package id.p2p.penangkap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

/**
 * NOTIFIKASI UJI (v5) — tes dua arah dari dashboard.
 *
 * Dashboard menitipkan kode uji di jawaban detak. Aplikasi membuat notifikasi
 * kecil dari dirinya sendiri; DanaListener (penangkap) harus MENANGKAP
 * notifikasi itu lalu melaporkannya ke dashboard. Jadi yang diuji adalah
 * jalur yang sama dengan uang sungguhan: akses notifikasi → penangkap →
 * internet → dashboard. Laporan uji TIDAK PERNAH dihitung sebagai uang.
 *
 * Notifikasi uji senyap (tanpa suara/getar) dan dihapus otomatis begitu
 * tertangkap; kalau tidak tertangkap, hilang sendiri setelah 30 menit.
 */
public final class UjiNotif {

    static final String KUNCI_EXTRA = "p2p_uji";
    private static final String CHANNEL = "penangkap_uji";
    private static final int ID_NOTIF = 7705;

    private UjiNotif() {}

    public static void buat(Context c, String kode) {
        if (kode == null || kode.isEmpty()) return;
        if (kode.equals(Penyimpan.ujiTerakhir(c))) return;          // sudah dibuat untuk kode ini
        Penyimpan.simpanUjiTerakhir(c, kode);
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Notifikasi uji penangkap",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                ch.enableVibration(false);
                nm.createNotificationChannel(ch);
            }
            Bundle ex = new Bundle();
            ex.putString(KUNCI_EXTRA, kode);
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(c, CHANNEL)
                    : new Notification.Builder(c);
            b.setContentTitle("Uji penangkap");
            b.setContentText("Notifikasi uji otomatis dari dashboard — hilang sendiri.");
            b.setSmallIcon(android.R.drawable.ic_dialog_email);
            b.setAutoCancel(true);
            b.addExtras(ex);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) b.setTimeoutAfter(30 * 60 * 1000L);
            nm.notify(ID_NOTIF, b.build());
            Penyimpan.catat(c, "🧪 Notifikasi uji dibuat (" + kode + ")");
        } catch (Exception e) {
            Penyimpan.catat(c, "✗ gagal membuat notifikasi uji: " + e.getMessage());
        }
    }
}
