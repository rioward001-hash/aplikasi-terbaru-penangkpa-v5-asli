package id.p2p.penangkap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Layanan latar depan: selama nyala, Android tidak membekukan aplikasi, jadi
 * HP tetap terdeteksi online di dashboard walau layar mati / tidak dicas.
 * Kalau saklar "Layar selalu nyala" juga ON, dipegang juga wake lock layar.
 * Dua saklar ini terpisah; layanan ini nyala kalau salah satu ON.
 */
public class OnlineService extends Service {

    private static final String CHANNEL = "penangkap_online";
    private static final int ID_NOTIF = 4201;
    private static final long JEDA_DETAK = 30_000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private boolean jalan = false;

    private final Runnable detak = new Runnable() {
        @Override public void run() {
            if (!jalan) return;
            Jaringan.PEKERJA.execute(() -> {
                Jaringan.kirimAntrian(getApplicationContext());
                Jaringan.detak(getApplicationContext());
            });
            handler.postDelayed(this, JEDA_DETAK);
        }
    };

    public static void perbarui(Context c) {
        boolean perlu = Penyimpan.jagaOnline(c) || Penyimpan.layarNyala(c);
        Intent i = new Intent(c, OnlineService.class);
        if (perlu) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i);
            else c.startService(i);
        } else {
            c.stopService(i);
        }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        mulaiForeground();
        aturWakeLock();
        jalan = true;
        handler.removeCallbacks(detak);
        handler.post(detak);
        return START_STICKY;
    }

    private void mulaiForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Status penangkap",
                        NotificationManager.IMPORTANCE_MIN);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setContentTitle("Penangkap DANA aktif");
        b.setContentText("Menjaga HP tetap online untuk dashboard.");
        b.setSmallIcon(android.R.drawable.ic_dialog_email);
        b.setOngoing(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setPriority(Notification.PRIORITY_MIN);
        }
        startForeground(ID_NOTIF, b.build());
    }

    @SuppressWarnings("deprecation")
    private void aturWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null) return;
        boolean mauLayar = Penyimpan.layarNyala(this);
        if (mauLayar && wl == null) {
            // SCREEN_BRIGHT_WAKE_LOCK sudah usang tapi masih bekerja di Android 9/10/11 (Oppo A5 2020).
            wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "penangkap:layar");
            wl.setReferenceCounted(false);
            try { wl.acquire(); } catch (Exception ignored) {}
        } else if (!mauLayar && wl != null) {
            try { if (wl.isHeld()) wl.release(); } catch (Exception ignored) {}
            wl = null;
        }
    }

    @Override public void onDestroy() {
        jalan = false;
        handler.removeCallbacks(detak);
        if (wl != null) { try { if (wl.isHeld()) wl.release(); } catch (Exception ignored) {} wl = null; }
        super.onDestroy();
    }
}
